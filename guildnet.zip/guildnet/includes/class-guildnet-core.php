<?php
class Guildnet_Core {
    public function init() {
        // Register post types on 'init' hook
        add_action('init', [$this, 'register_post_types'], 20);
        // Register rewrite rules and create pages
        $this->register_rewrite_rules();
        $this->create_pages();
        // Flush rewrite rules if needed
        add_action('init', [$this, 'flush_rewrite_rules']);
        // Initialize other components
        Guildnet_Shortcodes::register();
        Guildnet_Ajax::register();
        Guildnet_Woocommerce::register();
        Guildnet_Telegram::register();
    }

    public function register_post_types() {
        // Ensure $wp_rewrite is available
        global $wp_rewrite;
        if (!$wp_rewrite) {
            return; // If $wp_rewrite is not available, skip registration
        }

        register_post_type('guildnet_clan', [
            'labels' => [
                'name' => __('کلن‌ها', 'guildnet'),
                'singular_name' => __('کلن', 'guildnet')
            ],
            'public' => true,
            'has_archive' => false,
            'supports' => ['title', 'excerpt', 'thumbnail'],
            'show_in_rest' => true,
            'rewrite' => false // Temporarily disable rewrite to test
        ]);

        register_post_type('guildnet_tournament', [
            'labels' => [
                'name' => __('تورنمنت‌ها', 'guildnet'),
                'singular_name' => __('تورنمنت', 'guildnet')
            ],
            'public' => true,
            'has_archive' => false,
            'supports' => ['title', 'excerpt'],
            'show_in_rest' => true,
            'rewrite' => false // Temporarily disable rewrite to test
        ]);
    }

    public function create_pages() {
        $pages = [
            'dashboard' => [
                'title' => __('گیلدنت', 'guildnet'), // Changed to "Guildnet"
                'content' => '[guildnet_dashboard]'
            ],
            'clans' => [
                'title' => __('کلن‌ها', 'guildnet'),
                'content' => '[guildnet_clans]'
            ],
            'tournaments' => [
                'title' => __('تورنمنت‌ها', 'guildnet'),
                'content' => '[guildnet_tournaments]'
            ],
            'rewards' => [
                'title' => __('جوایز', 'guildnet'),
                'content' => '[guildnet_rewards]'
            ]
        ];

        foreach ($pages as $slug => $page) {
            if (!get_page_by_path($slug)) {
                wp_insert_post([
                    'post_title' => $page['title'],
                    'post_content' => $page['content'],
                    'post_status' => 'publish',
                    'post_type' => 'page',
                    'post_name' => $slug
                ]);
            }
        }
    }

    public function get_page_id($slug) {
        $page = get_page_by_path($slug);
        return $page ? $page->ID : 0;
    }

    public function register_rewrite_rules() {
        add_rewrite_rule(
            '^guildnet-dashboard/?$',
            'index.php?page_id=' . $this->get_page_id('dashboard'),
            'top'
        );
        add_rewrite_rule(
            '^guildnet-clans/?$',
            'index.php?page_id=' . $this->get_page_id('clans'),
            'top'
        );
        add_rewrite_rule(
            '^guildnet-tournaments/?$',
            'index.php?page_id=' . $this->get_page_id('tournaments'),
            'top'
        );
        add_rewrite_rule(
            '^guildnet-rewards/?$',
            'index.php?page_id=' . $this->get_page_id('rewards'),
            'top'
        );
    }

    public function flush_rewrite_rules() {
        if (get_option('guildnet_rewrite_flushed') !== '1') {
            flush_rewrite_rules();
            update_option('guildnet_rewrite_flushed', '1');
        }
    }
}
?>