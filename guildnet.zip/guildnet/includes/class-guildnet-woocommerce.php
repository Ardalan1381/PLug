<?php
class Guildnet_Woocommerce {
    public static function register() {
        if (class_exists('WooCommerce')) {
            add_action('add_meta_boxes', [self::class, 'add_gns_meta_box']);
            add_action('save_post', [self::class, 'save_gns_meta_box']);
        }
    }

    public static function add_gns_meta_box() {
        add_meta_box(
            'guildnet_gns_meta_box',
            'تنظیمات GNS (Guildnet)',
            [self::class, 'render_gns_meta_box'],
            'product',
            'side',
            'default'
        );
    }

    public static function render_gns_meta_box($post) {
        $gns_required = get_post_meta($post->ID, 'guildnet_gns_required', true);
        wp_nonce_field('guildnet_gns_meta_box_nonce', 'guildnet_gns_meta_box_nonce');
        ?>
        <label for="guildnet_gns_required">امتیاز GNS لازم برای خرید:</label>
        <input type="number" name="guildnet_gns_required" id="guildnet_gns_required" value="<?php echo esc_attr($gns_required); ?>" min="0" step="1">
        <?php
    }

    public static function save_gns_meta_box($post_id) {
        if (!isset($_POST['guildnet_gns_meta_box_nonce']) || !wp_verify_nonce($_POST['guildnet_gns_meta_box_nonce'], 'guildnet_gns_meta_box_nonce')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (isset($_POST['guildnet_gns_required'])) {
            $gns_required = intval($_POST['guildnet_gns_required']);
            if ($gns_required > 0) {
                update_post_meta($post_id, 'guildnet_gns_required', $gns_required);
            } else {
                delete_post_meta($post_id, 'guildnet_gns_required');
            }
        }
    }
}
?>