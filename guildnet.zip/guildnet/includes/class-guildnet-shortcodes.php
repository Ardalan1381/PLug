<?php
class Guildnet_Shortcodes {
    public static function register() {
        add_shortcode('guildnet_dashboard', [self::class, 'dashboard']);
        add_shortcode('guildnet_clans', [self::class, 'clans']);
        add_shortcode('guildnet_tournaments', [self::class, 'tournaments']);
        add_shortcode('guildnet_rewards', [self::class, 'rewards']);
    }

    public static function dashboard() {
        if (!is_user_logged_in()) {
            return '<p class="text-center">لطفاً ابتدا وارد شوید.</p>';
        }

        $user_id = get_current_user_id();
        $user = wp_get_current_user();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        $gns = get_user_meta($user_id, 'guildnet_gns', true) ?: 0;
        ob_start();
        ?>
        <div class="guildnet-header">
            <h1 class="guildnet-logo">Guildnet</h1>
        </div>
        <div class="guildnet-nav">
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('clans'))); ?>">کلن‌ها</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('rewards'))); ?>">جوایز</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('tournaments'))); ?>">تورنمنت‌ها</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('dashboard'))); ?>">گیلدنت</a>
        </div>
        <div class="guildnet-container">
            <div class="guildnet-welcome">
                <img src="<?php echo esc_url($clan ? get_the_post_thumbnail_url($clan['id']) : 'https://via.placeholder.com/100'); ?>" alt="Clan Logo">
                <div>
                    <h2>خوش آمدی، <?php echo esc_html($user->display_name); ?>!</h2>
                    <?php if ($clan) : ?>
                        <p>کلن: <?php echo esc_html(get_the_title($clan['id'])); ?> - <?php echo esc_html($clan['role']); ?></p>
                    <?php else : ?>
                        <p>شما هنوز عضو کلنی نیستید.</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="guildnet-gns">
                <h3>امتیاز GNS فعلی</h3>
                <span><?php echo esc_html($gns); ?></span>
            </div>
            <?php if ($clan) : ?>
                <h3>کلن فعلی شما</h3>
                <div class="guildnet-card">
                    <div class="flex items-center mb-4">
                        <img src="<?php echo esc_url(get_the_post_thumbnail_url($clan['id']) ?: 'https://via.placeholder.com/60'); ?>" alt="Clan Logo" class="w-12 h-12 rounded-full border-2 border-white shadow-sm ml-3">
                        <div>
                            <h3 class="font-bold text-lg"><?php echo esc_html(get_the_title($clan['id'])); ?></h3>
                            <div class="flex items-center text-sm text-gray-400">
                                <i class="fas fa-users ml-1"></i>
                                <span><?php echo esc_html(count(get_post_meta($clan['id'], 'guildnet_members', true) ?: [])); ?> عضو</span>
                            </div>
                        </div>
                    </div>
                    <p class="text-sm text-gray-400 mb-3"><?php echo esc_html(get_the_excerpt($clan['id'])); ?></p>
                    <?php if ($clan['role'] === 'leader') : ?>
                        <button class="guildnet-button" id="guildnet-buy-slot" data-clan-id="<?php echo esc_attr($clan['id']); ?>">خرید اسلات</button>
                    <?php endif; ?>
                    <button class="guildnet-button" id="guildnet-leave-clan" data-clan-id="<?php echo esc_attr($clan['id']); ?>">ترک کلن</button>
                    <?php if ($clan['role'] === 'leader' || $clan['role'] === 'seneschal') : ?>
                        <button class="guildnet-button" id="guildnet-load-join-requests">درخواست‌های عضویت</button>
                        <button class="guildnet-button" id="guildnet-load-members">مدیریت اعضا</button>
                    <?php endif; ?>
                    <?php if ($clan['role'] === 'leader') : ?>
                        <button class="guildnet-button" id="guildnet-load-tournament-registration">ثبت‌نام تورنمنت</button>
                    <?php endif; ?>
                </div>
                <div id="guildnet-join-requests"></div>
                <div id="guildnet-members"></div>
                <div id="guildnet-tournament-registration"></div>
            <?php endif; ?>
            <h3>تورنمنت‌های پیش‌رو</h3>
            <div id="guildnet-tournaments-upcoming" class="guildnet-grid"></div>
            <div class="text-center">
                <button class="guildnet-button" id="guildnet-load-tournaments">نمایش تورنمنت‌ها</button>
            </div>
        </div>
        <footer class="guildnet-footer">
            <p>Powered by <span class="guildnet-logo">Guildnet</span></p>
        </footer>
        <?php
        return ob_get_clean();
    }

    public static function clans() {
        if (!is_user_logged_in()) {
            return '<p class="text-center">لطفاً ابتدا وارد شوید.</p>';
        }

        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        ob_start();
        ?>
        <div class="guildnet-header">
            <h1 class="guildnet-logo">Guildnet</h1>
        </div>
        <div class="guildnet-nav">
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('clans'))); ?>">کلن‌ها</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('rewards'))); ?>">جوایز</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('tournaments'))); ?>">تورنمنت‌ها</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('dashboard'))); ?>">گیلدنت</a>
        </div>
        <div class="guildnet-container">
            <?php if (!$clan) : ?>
                <h3>ایجاد کلن</h3>
                <form id="guildnet-create-clan" enctype="multipart/form-data">
                    <label for="clan_name">نام کلن:</label>
                    <input type="text" name="clan_name" required>
                    <label for="clan_description">توضیحات:</label>
                    <textarea name="clan_description"></textarea>
                    <label for="clan_logo">لوگوی کلن:</label>
                    <input type="file" name="clan_logo" accept="image/*">
                    <button type="submit" class="guildnet-button glow-effect mt-4">ایجاد کلن</button>
                </form>
            <?php endif; ?>
            <?php if ($clan && $clan['role'] === 'leader') : ?>
                <h3>ویرایش کلن</h3>
                <form id="guildnet-update-clan" enctype="multipart/form-data">
                    <label for="clan_name">نام کلن:</label>
                    <input type="text" name="clan_name" value="<?php echo esc_attr(get_the_title($clan['id'])); ?>" required>
                    <label for="clan_description">توضیحات:</label>
                    <textarea name="clan_description"><?php echo esc_textarea(get_the_excerpt($clan['id'])); ?></textarea>
                    <label for="clan_logo">لوگوی کلن:</label>
                    <input type="file" name="clan_logo" accept="image/*">
                    <button type="submit" class="guildnet-button glow-effect mt-4">ذخیره تغییرات</button>
                </form>
            <?php endif; ?>
            <h3>کلن‌ها</h3>
            <div id="guildnet-clans-list" class="guildnet-grid"></div>
            <div class="text-center">
                <button class="guildnet-button" id="guildnet-load-clans">نمایش کلن‌ها</button>
            </div>
        </div>
        <footer class="guildnet-footer">
            <p>Powered by <span class="guildnet-logo">Guildnet</span></p>
        </footer>
        <?php
        return ob_get_clean();
    }

    public static function tournaments() {
        if (!is_user_logged_in()) {
            return '<p class="text-center">لطفاً ابتدا وارد شوید.</p>';
        }

        ob_start();
        ?>
        <div class="guildnet-header">
            <h1 class="guildnet-logo">Guildnet</h1>
        </div>
        <div class="guildnet-nav">
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('clans'))); ?>">کلن‌ها</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('rewards'))); ?>">جوایز</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('tournaments'))); ?>">تورنمنت‌ها</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('dashboard'))); ?>">گیلدنت</a>
        </div>
        <div class="guildnet-container">
            <h3>تورنمنت‌های جاری</h3>
            <div id="guildnet-tournaments-current" class="guildnet-grid"></div>
            <h3>تورنمنت‌های آتی</h3>
            <div id="guildnet-tournaments-upcoming" class="guildnet-grid"></div>
            <h3>تورنمنت‌های گذشته</h3>
            <table id="guildnet-tournaments-past">
                <thead>
                    <tr class="text-right text-xs text-gray-400 border-b">
                        <th>تورنمنت</th>
                        <th>تاریخ پایان</th>
                        <th>رتبه</th>
                        <th>جایزه</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
            <div class="text-center">
                <button class="guildnet-button" id="guildnet-load-tournaments">نمایش تورنمنت‌ها</button>
            </div>
        </div>
        <footer class="guildnet-footer">
            <p>Powered by <span class="guildnet-logo">Guildnet</span></p>
        </footer>
        <?php
        return ob_get_clean();
    }

    public static function rewards() {
        if (!is_user_logged_in()) {
            return '<p class="text-center">لطفاً ابتدا وارد شوید.</p>';
        }

        if (!class_exists('WooCommerce')) {
            return '<p class="text-center">ووکامرس نصب نشده است.</p>';
        }

        $user_id = get_current_user_id();
        $coupons = get_user_meta($user_id, 'guildnet_coupons', true) ?: [];
        $products = wc_get_products([
            'limit' => -1,
            'meta_key' => 'guildnet_gns_required',
            'meta_compare' => 'EXISTS'
        ]);
        ob_start();
        ?>
        <div class="guildnet-header">
            <h1 class="guildnet-logo">Guildnet</h1>
        </div>
        <div class="guildnet-nav">
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('clans'))); ?>">کلن‌ها</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('rewards'))); ?>">جوایز</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('tournaments'))); ?>">تورنمنت‌ها</a>
            <a href="<?php echo esc_url(get_permalink(get_page_by_path('dashboard'))); ?>">گیلدنت</a>
        </div>
        <div class="guildnet-container">
            <h3>جوایز</h3>
            <div class="guildnet-grid">
                <?php foreach ($products as $product) : ?>
                    <?php
                    $gns_required = get_post_meta($product->get_id(), 'guildnet_gns_required', true);
                    ?>
                    <div class="guildnet-card">
                        <h3 class="font-bold"><?php echo esc_html($product->get_name()); ?></h3>
                        <p class="text-sm text-gray-400 mb-3"><?php echo esc_html($product->get_description()); ?></p>
                        <div class="flex items-center justify-between">
                            <span class="text-pink-600 font-bold"><?php echo esc_html($gns_required); ?> GNS</span>
                            <button class="guildnet-button guildnet-purchase-reward" data-product-id="<?php echo esc_attr($product->get_id()); ?>">خرید</button>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <h3>کوپن‌های شما</h3>
            <?php if ($coupons) : ?>
                <ul class="divide-y">
                    <?php foreach ($coupons as $coupon) : ?>
                        <li class="py-2"><?php echo esc_html($coupon); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p class="text-gray-400">کوپنی وجود ندارد.</p>
            <?php endif; ?>
        </div>
        <footer class="guildnet-footer">
            <p>Powered by <span class="guildnet-logo">Guildnet</span></p>
        </footer>
        <?php
        return ob_get_clean();
    }
}
?>