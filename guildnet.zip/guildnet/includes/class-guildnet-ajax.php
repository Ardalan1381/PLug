<?php
class Guildnet_Ajax {
    public static function register() {
        add_action('wp_ajax_guildnet_load_clans', [self::class, 'load_clans']);
        add_action('wp_ajax_guildnet_create_clan', [self::class, 'create_clan']);
        add_action('wp_ajax_guildnet_join_clan', [self::class, 'join_clan']);
        add_action('wp_ajax_guildnet_leave_clan', [self::class, 'leave_clan']);
        add_action('wp_ajax_guildnet_update_clan', [self::class, 'update_clan']);
        add_action('wp_ajax_guildnet_load_join_requests', [self::class, 'load_join_requests']);
        add_action('wp_ajax_guildnet_approve_join', [self::class, 'approve_join']);
        add_action('wp_ajax_guildnet_reject_join', [self::class, 'reject_join']);
        add_action('wp_ajax_guildnet_load_members', [self::class, 'load_members']);
        add_action('wp_ajax_guildnet_assign_role', [self::class, 'assign_role']);
        add_action('wp_ajax_guildnet_kick_member', [self::class, 'kick_member']);
        add_action('wp_ajax_guildnet_buy_slot', [self::class, 'buy_slot']);
        add_action('wp_ajax_guildnet_load_tournaments', [self::class, 'load_tournaments']);
        add_action('wp_ajax_guildnet_load_tournament_registration', [self::class, 'load_tournament_registration']);
        add_action('wp_ajax_guildnet_register_tournament', [self::class, 'register_tournament']);
        add_action('wp_ajax_guildnet_purchase_reward', [self::class, 'purchase_reward']);
        add_action('wp_ajax_guildnet_pay_tournament_entry', [self::class, 'pay_tournament_entry']); // New AJAX action
    }

    public static function load_clans() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $args = [
            'post_type' => 'guildnet_clan',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ];
        $clans = get_posts($args);
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        ob_start();
        foreach ($clans as $c) {
            $members = get_post_meta($c->ID, 'guildnet_members', true) ?: [];
            $slots = get_post_meta($c->ID, 'guildnet_slots', true) ?: 5;
            ?>
            <div class="guildnet-card">
                <div class="flex items-center mb-4">
                    <img src="<?php echo esc_url(get_the_post_thumbnail_url($c->ID) ?: 'https://via.placeholder.com/60'); ?>" alt="Clan Logo" class="w-12 h-12 rounded-full border-2 border-white shadow-sm ml-3">
                    <div>
                        <h3 class="font-bold text-lg"><?php echo esc_html($c->post_title); ?></h3>
                        <div class="flex items-center text-sm text-gray-400">
                            <i class="fas fa-users ml-1"></i>
                            <span><?php echo esc_html(count($members)); ?>/<?php echo esc_html($slots); ?> عضو</span>
                        </div>
                    </div>
                </div>
                <p class="text-sm text-gray-400 mb-3"><?php echo esc_html(get_the_excerpt($c->ID)); ?></p>
                <?php if (!$clan) : ?>
                    <button class="guildnet-button join-clan" data-clan-id="<?php echo esc_attr($c->ID); ?>">پیوستن</button>
                <?php endif; ?>
            </div>
            <?php
        }
        $html = ob_get_clean();
        wp_send_json_success($html);
    }

    public static function create_clan() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        if ($clan) {
            wp_send_json_error(['message' => 'شما قبلاً عضو یک کلن هستید.']);
        }

        $name = sanitize_text_field($_POST['clan_name']);
        $description = sanitize_textarea_field($_POST['clan_description']);
        if (empty($name)) {
            wp_send_json_error(['message' => 'نام کلن الزامی است.']);
        }

        $clan_id = wp_insert_post([
            'post_title' => $name,
            'post_excerpt' => $description,
            'post_type' => 'guildnet_clan',
            'post_status' => 'publish'
        ]);

        if (is_wp_error($clan_id)) {
            wp_send_json_error(['message' => 'خطا در ایجاد کلن.']);
        }

        if (!empty($_FILES['clan_logo']['name'])) {
            $attachment_id = media_handle_upload('clan_logo', $clan_id);
            if (!is_wp_error($attachment_id)) {
                set_post_thumbnail($clan_id, $attachment_id);
            }
        }

        update_post_meta($clan_id, 'guildnet_members', [$user_id]);
        update_post_meta($clan_id, 'guildnet_slots', 5);
        update_post_meta($clan_id, 'guildnet_gns', 0);
        update_user_meta($user_id, 'guildnet_clan', ['id' => $clan_id, 'role' => 'leader']);
        wp_send_json_success(['message' => 'کلن با موفقیت ایجاد شد.']);
    }

    public static function join_clan() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan_id = intval($_POST['clan_id']);
        $clan = get_user_meta($user_id, 'guildnet_clan', true);

        if ($clan) {
            wp_send_json_error(['message' => 'شما قبلاً عضو یک کلن هستید.']);
        }

        $members = get_post_meta($clan_id, 'guildnet_members', true) ?: [];
        $slots = get_post_meta($clan_id, 'guildnet_slots', true) ?: 5;
        if (count($members) >= $slots) {
            wp_send_json_error(['message' => 'ظرفیت کلن پر شده است.']);
        }

        $join_requests = get_post_meta($clan_id, 'guildnet_join_requests', true) ?: [];
        if (in_array($user_id, $join_requests)) {
            wp_send_json_error(['message' => 'شما قبلاً درخواست داده‌اید.']);
        }

        $join_requests[] = $user_id;
        update_post_meta($clan_id, 'guildnet_join_requests', $join_requests);
        wp_send_json_success(['message' => 'درخواست شما برای پیوستن به کلن ارسال شد.']);
    }

    public static function leave_clan() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan_id = intval($_POST['clan_id']);
        $clan = get_user_meta($user_id, 'guildnet_clan', true);

        if (!$clan || $clan['id'] != $clan_id) {
            wp_send_json_error(['message' => 'شما عضو این کلن نیستید.']);
        }

        $members = get_post_meta($clan_id, 'guildnet_members', true) ?: [];
        $members = array_diff($members, [$user_id]);
        update_post_meta($clan_id, 'guildnet_members', $members);
        delete_user_meta($user_id, 'guildnet_clan');

        if (empty($members)) {
            wp_delete_post($clan_id, true);
        } elseif ($clan['role'] === 'leader') {
            $new_leader = !empty($members) ? $members[0] : null;
            if ($new_leader) {
                update_user_meta($new_leader, 'guildnet_clan', ['id' => $clan_id, 'role' => 'leader']);
            }
        }

        wp_send_json_success(['message' => 'شما با موفقیت کلن را ترک کردید.']);
    }

    public static function update_clan() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);

        if (!$clan || $clan['role'] !== 'leader') {
            wp_send_json_error(['message' => 'شما اجازه ویرایش کلن را ندارید.']);
        }

        $name = sanitize_text_field($_POST['clan_name']);
        $description = sanitize_textarea_field($_POST['clan_description']);
        if (empty($name)) {
            wp_send_json_error(['message' => 'نام کلن الزامی است.']);
        }

        wp_update_post([
            'ID' => $clan['id'],
            'post_title' => $name,
            'post_excerpt' => $description
        ]);

        if (!empty($_FILES['clan_logo']['name'])) {
            $attachment_id = media_handle_upload('clan_logo', $clan['id']);
            if (!is_wp_error($attachment_id)) {
                set_post_thumbnail($clan['id'], $attachment_id);
            }
        }

        wp_send_json_success(['message' => 'کلن با موفقیت به‌روزرسانی شد.']);
    }

    public static function load_join_requests() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);

        if (!$clan || !in_array($clan['role'], ['leader', 'seneschal'])) {
            wp_send_json_error(['message' => 'شما اجازه مشاهده درخواست‌ها را ندارید.']);
        }

        $join_requests = get_post_meta($clan['id'], 'guildnet_join_requests', true) ?: [];
        ob_start();
        if ($join_requests) {
            ?>
            <table>
                <thead>
                    <tr class="text-right text-xs text-gray-400 border-b">
                        <th>کاربر</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($join_requests as $user_id) : ?>
                        <tr>
                            <td><?php echo esc_html(get_userdata($user_id)->display_name); ?></td>
                            <td>
                                <button class="guildnet-button approve-join" data-user-id="<?php echo esc_attr($user_id); ?>" data-clan-id="<?php echo esc_attr($clan['id']); ?>">تأیید</button>
                                <button class="guildnet-button reject-join" data-user-id="<?php echo esc_attr($user_id); ?>" data-clan-id="<?php echo esc_attr($clan['id']); ?>">رد</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php
        } else {
            echo '<p class="text-gray-400">درخواستی برای پیوستن وجود ندارد.</p>';
        }
        $html = ob_get_clean();
        wp_send_json_success($html);
    }

    public static function approve_join() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        $target_user_id = intval($_POST['user_id']);
        $clan_id = intval($_POST['clan_id']);

        if (!$clan || !in_array($clan['role'], ['leader', 'seneschal']) || $clan['id'] != $clan_id) {
            wp_send_json_error(['message' => 'شما اجازه تأیید درخواست را ندارید.']);
        }

        $join_requests = get_post_meta($clan_id, 'guildnet_join_requests', true) ?: [];
        $members = get_post_meta($clan_id, 'guildnet_members', true) ?: [];
        $slots = get_post_meta($clan_id, 'guildnet_slots', true) ?: 5;

        if (!in_array($target_user_id, $join_requests)) {
            wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        }

        if (count($members) >= $slots) {
            wp_send_json_error(['message' => 'ظرفیت کلن پر شده است.']);
        }

        $join_requests = array_diff($join_requests, [$target_user_id]);
        $members[] = $target_user_id;
        update_post_meta($clan_id, 'guildnet_join_requests', $join_requests);
        update_post_meta($clan_id, 'guildnet_members', $members);
        update_user_meta($target_user_id, 'guildnet_clan', ['id' => $clan_id, 'role' => 'member']);
        wp_send_json_success(['message' => 'درخواست با موفقیت تأیید شد.']);
    }

    public static function reject_join() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        $target_user_id = intval($_POST['user_id']);
        $clan_id = intval($_POST['clan_id']);

        if (!$clan || !in_array($clan['role'], ['leader', 'seneschal']) || $clan['id'] != $clan_id) {
            wp_send_json_error(['message' => 'شما اجازه رد درخواست را ندارید.']);
        }

        $join_requests = get_post_meta($clan_id, 'guildnet_join_requests', true) ?: [];
        if (!in_array($target_user_id, $join_requests)) {
            wp_send_json_error(['message' => 'درخواست یافت نشد.']);
        }

        $join_requests = array_diff($join_requests, [$target_user_id]);
        update_post_meta($clan_id, 'guildnet_join_requests', $join_requests);
        wp_send_json_success(['message' => 'درخواست با موفقیت رد شد.']);
    }

    public static function load_members() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);

        if (!$clan || !in_array($clan['role'], ['leader', 'seneschal'])) {
            wp_send_json_error(['message' => 'شما اجازه مشاهده اعضا را ندارید.']);
        }

        $members = get_post_meta($clan['id'], 'guildnet_members', true) ?: [];
        ob_start();
        if ($members) {
            ?>
            <table>
                <thead>
                    <tr class="text-right text-xs text-gray-400 border-b">
                        <th>کاربر</th>
                        <th>نقش</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($members as $member_id) : ?>
                        <?php $member_clan = get_user_meta($member_id, 'guildnet_clan', true); ?>
                        <tr>
                            <td><?php echo esc_html(get_userdata($member_id)->display_name); ?></td>
                            <td>
                                <?php if ($clan['role'] === 'leader' && $member_id != $user_id) : ?>
                                    <select class="role-select" data-user-id="<?php echo esc_attr($member_id); ?>" data-clan-id="<?php echo esc_attr($clan['id']); ?>">
                                        <option value="member" <?php selected($member_clan['role'], 'member'); ?>>عضو</option>
                                        <option value="seneschal" <?php selected($member_clan['role'], 'seneschal'); ?>>سنشال</option>
                                    </select>
                                <?php else : ?>
                                    <?php echo esc_html($member_clan['role']); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($clan['role'] === 'leader' && $member_id != $user_id) : ?>
                                    <button class="guildnet-button kick-member" data-user-id="<?php echo esc_attr($member_id); ?>" data-clan-id="<?php echo esc_attr($clan['id']); ?>">اخراج</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php
        } else {
            echo '<p class="text-gray-400">عضوی وجود ندارد.</p>';
        }
        $html = ob_get_clean();
        wp_send_json_success($html);
    }

    public static function assign_role() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        $target_user_id = intval($_POST['user_id']);
        $clan_id = intval($_POST['clan_id']);
        $role = sanitize_text_field($_POST['role']);

        if (!$clan || $clan['role'] !== 'leader' || $clan['id'] != $clan_id) {
            wp_send_json_error(['message' => 'شما اجازه تغییر نقش را ندارید.']);
        }

        $members = get_post_meta($clan_id, 'guildnet_members', true) ?: [];
        if (!in_array($target_user_id, $members)) {
            wp_send_json_error(['message' => 'کاربر عضو کلن نیست.']);
        }

        if (!in_array($role, ['member', 'seneschal'])) {
            wp_send_json_error(['message' => 'نقش نامعتبر است.']);
        }

        update_user_meta($target_user_id, 'guildnet_clan', ['id' => $clan_id, 'role' => $role]);
        wp_send_json_success(['message' => 'نقش با موفقیت تغییر کرد.']);
    }

    public static function kick_member() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        $target_user_id = intval($_POST['user_id']);
        $clan_id = intval($_POST['clan_id']);

        if (!$clan || $clan['role'] !== 'leader' || $clan['id'] != $clan_id) {
            wp_send_json_error(['message' => 'شما اجازه اخراج اعضا را ندارید.']);
        }

        $members = get_post_meta($clan_id, 'guildnet_members', true) ?: [];
        if (!in_array($target_user_id, $members)) {
            wp_send_json_error(['message' => 'کاربر عضو کلن نیست.']);
        }

        $members = array_diff($members, [$target_user_id]);
        update_post_meta($clan_id, 'guildnet_members', $members);
        delete_user_meta($target_user_id, 'guildnet_clan');
        wp_send_json_success(['message' => 'عضو با موفقیت اخراج شد.']);
    }

    public static function buy_slot() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        $clan_id = intval($_POST['clan_id']);

        if (!$clan || $clan['role'] !== 'leader' || $clan['id'] != $clan_id) {
            wp_send_json_error(['message' => 'شما اجازه خرید اسلات را ندارید.']);
        }

        $clan_gns = get_post_meta($clan_id, 'guildnet_gns', true) ?: 0;
        $cost = 50;
        if ($clan_gns < $cost) {
            wp_send_json_error(['message' => 'GNS کافی برای خرید اسلات ندارید.']);
        }

        $slots = get_post_meta($clan_id, 'guildnet_slots', true) ?: 5;
        $slots += 1;
        $clan_gns -= $cost;
        update_post_meta($clan_id, 'guildnet_slots', $slots);
        update_post_meta($clan_id, 'guildnet_gns', $clan_gns);
        wp_send_json_success(['message' => 'اسلات با موفقیت خریداری شد.']);
    }

    public static function load_tournaments() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $args = [
            'post_type' => 'guildnet_tournament',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ];
        $tournaments = get_posts($args);
        $current = $upcoming = $past = '';
        $now = current_time('timestamp');
        $clan = get_user_meta($user_id, 'guildnet_clan', true);

        foreach ($tournaments as $t) {
            $start = get_post_meta($t->ID, 'guildnet_start_date', true);
            $end = get_post_meta($t->ID, 'guildnet_end_date', true);
            $entry_fee = get_post_meta($t->ID, 'guildnet_entry_fee', true) ?: 0; // New meta for entry fee
            $registered_clans = get_post_meta($t->ID, 'guildnet_registered_clans', true) ?: [];
            $start_ts = strtotime($start);
            $end_ts = strtotime($end);

            $card = '<div class="guildnet-card">';
            $card .= '<h3 class="font-bold">' . esc_html($t->post_title) . '</h3>';
            $card .= '<p class="text-sm text-gray-400 mb-3">' . esc_html(get_the_excerpt($t->ID)) . '</p>';
            $card .= '<p class="text-sm">شروع: ' . esc_html($start) . '</p>';
            $card .= '<p class="text-sm">پایان: ' . esc_html($end) . '</p>';
            if ($entry_fee > 0) {
                $card .= '<p class="text-sm text-pink-600 font-bold">ورودی: ' . esc_html($entry_fee) . ' GNS</p>';
            }

            if ($clan && $clan['role'] === 'leader') {
                if (in_array($clan['id'], $registered_clans)) {
                    $card .= '<p class="text-green-800 bg-green-100 rounded px-2 py-0.5 mt-2">ثبت‌نام شده</p>';
                } elseif ($now < $start_ts) {
                    if ($entry_fee > 0) {
                        $card .= '<button class="guildnet-button pay-tournament-entry mt-2" data-tournament-id="' . esc_attr($t->ID) . '" data-clan-id="' . esc_attr($clan['id']) . '" data-entry-fee="' . esc_attr($entry_fee) . '">پرداخت و ثبت‌نام</button>';
                    } else {
                        $card .= '<button class="guildnet-button register-tournament mt-2" data-tournament-id="' . esc_attr($t->ID) . '" data-clan-id="' . esc_attr($clan['id']) . '">ثبت‌نام</button>';
                    }
                }
            }
            $card .= '</div>';

            if ($now >= $start_ts && $now <= $end_ts) {
                $current .= $card;
            } elseif ($now < $start_ts) {
                $upcoming .= $card;
            } else {
                $past .= '<tr>';
                $past .= '<td>' . esc_html($t->post_title) . '</td>';
                $past .= '<td>' . esc_html($end) . '</td>';
                $past .= '<td>-</td>';
                $past .= '<td>-</td>';
                $past .= '</tr>';
            }
        }

        wp_send_json_success([
            'current' => $current ?: '<p class="text-gray-400">تورنمنت جاری وجود ندارد.</p>',
            'upcoming' => $upcoming ?: '<p class="text-gray-400">تورنمنت آتی وجود ندارد.</p>',
            'past' => $past ?: '<tr><td colspan="4" class="text-gray-400">تورنمنت گذشته‌ای وجود ندارد.</td></tr>'
        ]);
    }

    public static function load_tournament_registration() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);

        if (!$clan || $clan['role'] !== 'leader') {
            wp_send_json_error(['message' => 'شما اجازه ثبت‌نام تورنمنت را ندارید.']);
        }

        $args = [
            'post_type' => 'guildnet_tournament',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        ];
        $tournaments = get_posts($args);
        $now = current_time('timestamp');
        ob_start();
        ?>
        <form id="guildnet-register-tournament">
            <label for="tournament_id">انتخاب تورنمنت:</label>
            <select name="tournament_id" required>
                <option value="">تورنمنت را انتخاب کنید</option>
                <?php foreach ($tournaments as $t) : ?>
                    <?php
                    $start = get_post_meta($t->ID, 'guildnet_start_date', true);
                    $start_ts = strtotime($start);
                    $registered_clans = get_post_meta($t->ID, 'guildnet_registered_clans', true) ?: [];
                    if ($now < $start_ts && !in_array($clan['id'], $registered_clans)) :
                    ?>
                        <option value="<?php echo esc_attr($t->ID); ?>"><?php echo esc_html($t->post_title); ?></option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="guildnet-button mt-4">ثبت‌نام</button>
        </form>
        <?php
        $html = ob_get_clean();
        wp_send_json_success($html);
    }

    public static function register_tournament() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        $tournament_id = intval($_POST['tournament_id']);

        if (!$clan || $clan['role'] !== 'leader') {
            wp_send_json_error(['message' => 'شما اجازه ثبت‌نام تورنمنت را ندارید.']);
        }

        $start = get_post_meta($tournament_id, 'guildnet_start_date', true);
        $now = current_time('timestamp');
        $start_ts = strtotime($start);
        if ($now >= $start_ts) {
            wp_send_json_error(['message' => 'زمان ثبت‌نام تورنمنت به پایان رسیده است.']);
        }

        $registered_clans = get_post_meta($tournament_id, 'guildnet_registered_clans', true) ?: [];
        if (in_array($clan['id'], $registered_clans)) {
            wp_send_json_error(['message' => 'کلن شما قبلاً ثبت‌نام کرده است.']);
        }

        $entry_fee = get_post_meta($tournament_id, 'guildnet_entry_fee', true) ?: 0;
        if ($entry_fee > 0) {
            wp_send_json_error(['message' => 'این تورنمنت نیاز به پرداخت ورودی دارد. لطفاً از دکمه پرداخت استفاده کنید.']);
        }

        $registered_clans[] = $clan['id'];
        update_post_meta($tournament_id, 'guildnet_registered_clans', $registered_clans);
        wp_send_json_success(['message' => 'کلن شما با موفقیت در تورنمنت ثبت‌نام کرد.']);
    }

    public static function pay_tournament_entry() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $clan = get_user_meta($user_id, 'guildnet_clan', true);
        $tournament_id = intval($_POST['tournament_id']);
        $clan_id = intval($_POST['clan_id']);
        $entry_fee = intval($_POST['entry_fee']);

        if (!$clan || $clan['role'] !== 'leader' || $clan['id'] != $clan_id) {
            wp_send_json_error(['message' => 'شما اجازه پرداخت ورودی تورنمنت را ندارید.']);
        }

        $start = get_post_meta($tournament_id, 'guildnet_start_date', true);
        $now = current_time('timestamp');
        $start_ts = strtotime($start);
        if ($now >= $start_ts) {
            wp_send_json_error(['message' => 'زمان ثبت‌نام تورنمنت به پایان رسیده است.']);
        }

        $registered_clans = get_post_meta($tournament_id, 'guildnet_registered_clans', true) ?: [];
        if (in_array($clan_id, $registered_clans)) {
            wp_send_json_error(['message' => 'کلن شما قبلاً ثبت‌نام کرده است.']);
        }

        $clan_gns = get_post_meta($clan_id, 'guildnet_gns', true) ?: 0;
        if ($clan_gns < $entry_fee) {
            wp_send_json_error(['message' => 'GNS کافی برای پرداخت ورودی ندارید.']);
        }

        $clan_gns -= $entry_fee;
        update_post_meta($clan_id, 'guildnet_gns', $clan_gns);
        $registered_clans[] = $clan_id;
        update_post_meta($tournament_id, 'guildnet_registered_clans', $registered_clans);
        wp_send_json_success(['message' => 'پرداخت با موفقیت انجام شد و کلن شما در تورنمنت ثبت‌نام کرد.']);
    }

    public static function purchase_reward() {
        check_ajax_referer('guildnet_nonce', 'nonce');
        $user_id = get_current_user_id();
        $product_id = intval($_POST['product_id']);
        $gns_required = get_post_meta($product_id, 'guildnet_gns_required', true);
        $user_gns = get_user_meta($user_id, 'guildnet_gns', true) ?: 0;

        if ($user_gns < $gns_required) {
            wp_send_json_error(['message' => 'GNS کافی برای خرید این جایزه ندارید.']);
        }

        $user_gns -= $gns_required;
        update_user_meta($user_id, 'guildnet_gns', $user_gns);
        $coupon_code = 'GN' . strtoupper(substr(md5(uniqid()), 0, 8));
        $coupons = get_user_meta($user_id, 'guildnet_coupons', true) ?: [];
        $coupons[] = $coupon_code;
        update_user_meta($user_id, 'guildnet_coupons', $coupons);
        wp_send_json_success(['message' => 'جایزه با موفقیت خریداری شد. کد کوپن: ' . $coupon_code]);
    }
}
?>