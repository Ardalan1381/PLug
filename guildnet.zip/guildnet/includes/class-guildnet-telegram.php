<?php
class Guildnet_Telegram {
    private static $bot_token;
    private static $group_id;

    public static function register() {
        self::$bot_token = get_option('guildnet_bot_token', '');
        self::$group_id = get_option('guildnet_group_id', '');

        if (get_option('guildnet_auto_scoring_enabled', 0)) {
            add_action('wp_ajax_guildnet_update_scores', [self::class, 'update_scores']);
            add_action('wp_ajax_nopriv_guildnet_update_scores', [self::class, 'update_scores']);
        }
    }

    public static function update_scores() {
        if (empty(self::$bot_token) || empty(self::$group_id)) {
            wp_send_json_error(['message' => 'تنظیمات ربات تلگرام کامل نیست.']);
        }

        // Simulate fetching messages (in a real scenario, this would use Telegram API)
        $messages = self::fetch_messages();

        $user_messages = [];
        foreach ($messages as $message) {
            $user_id = self::get_user_id_from_telegram($message['user_id']);
            if (!$user_id) continue;

            if (self::is_member_of_group($message['user_id'])) {
                $text = trim($message['text']);
                $word_count = count(preg_split('/\s+/', $text));
                if ($word_count >= 3) {
                    $user_messages[$user_id] = ($user_messages[$user_id] ?? 0) + 1;
                }
            }
        }

        foreach ($user_messages as $user_id => $message_count) {
            $gns = get_user_meta($user_id, 'guildnet_gns', true) ?: 0;
            $new_gns = floor($message_count / 1000) * 100;
            if ($new_gns > 0) {
                update_user_meta($user_id, 'guildnet_gns', $gns + $new_gns);
            }
        }

        wp_send_json_success(['message' => 'امتیازات با موفقیت به‌روزرسانی شدند.']);
    }

    private static function fetch_messages() {
        // This is a placeholder. In a real scenario, you'd use Telegram Bot API to fetch messages.
        // Example API call: https://api.telegram.org/bot<token>/getUpdates
        return [
            ['user_id' => 'telegram_user_1', 'text' => 'سلام این یک پیام تستی است'],
            ['user_id' => 'telegram_user_2', 'text' => 'پیام کوتاه'],
            // Add more mock messages as needed
        ];
    }

    private static function is_member_of_group($telegram_user_id) {
        // Placeholder for checking group membership via Telegram API
        // Example API call: https://api.telegram.org/bot<token>/getChatMember
        return true; // Mock response
    }

    private static function get_user_id_from_telegram($telegram_user_id) {
        // Placeholder for mapping Telegram user ID to WordPress user ID
        // In a real scenario, you'd store this mapping in a database
        $map = [
            'telegram_user_1' => 1, // Example WordPress user ID
            'telegram_user_2' => 2,
        ];
        return $map[$telegram_user_id] ?? false;
    }
}
?>