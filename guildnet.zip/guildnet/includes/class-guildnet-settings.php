<?php
class Guildnet_Settings {
    public static function init() {
        add_action('admin_menu', [self::class, 'add_admin_menu']);
        add_action('admin_init', [self::class, 'register_settings']);
        add_action('add_meta_boxes', [self::class, 'add_tournament_meta_box']);
        add_action('save_post', [self::class, 'save_tournament_meta_box']);
        add_action('add_meta_boxes', [self::class, 'add_clan_meta_box']);
        add_action('save_post', [self::class, 'save_clan_meta_box']);
    }

    public static function add_admin_menu() {
        add_menu_page(
            'تنظیمات Guildnet',
            'Guildnet',
            'manage_options',
            'guildnet-settings',
            [self::class, 'render_settings_page'],
            'dashicons-games',
            20
        );

        add_submenu_page(
            'guildnet-settings',
            'مدیریت کاربران',
            'کاربران',
            'manage_options',
            'guildnet-users',
            [self::class, 'render_users_page']
        );
    }

    public static function register_settings() {
        register_setting('guildnet_settings_group', 'guildnet_min_gns_for_clan', ['default' => 1000]);
        register_setting('guildnet_settings_group', 'guildnet_bot_token');
        register_setting('guildnet_settings_group', 'guildnet_group_id');
        register_setting('guildnet_settings_group', 'guildnet_auto_scoring_enabled', ['default' => 0]);

        add_settings_section(
            'guildnet_general_section',
            'تنظیمات عمومی',
            null,
            'guildnet-settings'
        );

        add_settings_field(
            'guildnet_min_gns_for_clan',
            'حداقل GNS برای ایجاد کلن',
            [self::class, 'render_min_gns_field'],
            'guildnet-settings',
            'guildnet_general_section'
        );

        add_settings_field(
            'guildnet_bot_token',
            'توکن ربات تلگرام',
            [self::class, 'render_bot_token_field'],
            'guildnet-settings',
            'guildnet_general_section'
        );

        add_settings_field(
            'guildnet_group_id',
            'شناسه گروه تلگرام',
            [self::class, 'render_group_id_field'],
            'guildnet-settings',
            'guildnet_general_section'
        );

        add_settings_field(
            'guildnet_auto_scoring_enabled',
            'فعال‌سازی امتیازدهی خودکار',
            [self::class, 'render_auto_scoring_field'],
            'guildnet-settings',
            'guildnet_general_section'
        );
    }

    public static function render_min_gns_field() {
        $value = get_option('guildnet_min_gns_for_clan', 1000);
        echo '<input type="number" name="guildnet_min_gns_for_clan" value="' . esc_attr($value) . '" min="0" step="1">';
    }

    public static function render_bot_token_field() {
        $value = get_option('guildnet_bot_token', '');
        echo '<input type="text" name="guildnet_bot_token" value="' . esc_attr($value) . '" class="regular-text">';
    }

    public static function render_group_id_field() {
        $value = get_option('guildnet_group_id', '');
        echo '<input type="text" name="guildnet_group_id" value="' . esc_attr($value) . '" class="regular-text">';
    }

    public static function render_auto_scoring_field() {
        $value = get_option('guildnet_auto_scoring_enabled', 0);
        echo '<input type="checkbox" name="guildnet_auto_scoring_enabled" value="1"' . checked(1, $value, false) . '>';
    }

    public static function render_settings_page() {
        ?>
        <div class="wrap">
            <h1>تنظیمات Guildnet</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('guildnet_settings_group');
                do_settings_sections('guildnet-settings');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public static function render_users_page() {
        $users = get_users();
        if (isset($_POST['update_user_gns']) && check_admin_referer('guildnet_update_user_gns', 'guildnet_update_user_gns_nonce')) {
            $user_id = intval($_POST['user_id']);
            $new_gns = intval($_POST['new_gns']);
            update_user_meta($user_id, 'guildnet_gns', $new_gns);
            echo '<div class="updated"><p>امتیاز کاربر با موفقیت به‌روزرسانی شد.</p></div>';
        }

        ?>
        <div class="wrap">
            <h1>مدیریت کاربران</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>کاربر</th>
                        <th>امتیاز GNS</th>
                        <th>کلن</th>
                        <th>عضویت در گروه تلگرام</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user) : ?>
                        <tr>
                            <td><?php echo esc_html($user->display_name); ?></td>
                            <td><?php echo esc_html(get_user_meta($user->ID, 'guildnet_gns', true) ?: 0); ?></td>
                            <td>
                                <?php
                                $clan = get_user_meta($user->ID, 'guildnet_clan', true);
                                echo $clan ? esc_html(get_the_title($clan['id'])) . ' (' . esc_html($clan['role']) . ')' : 'عضو نیست';
                                ?>
                            </td>
                            <td>
                                <?php
                                // Placeholder for Telegram group membership check
                                echo 'بله'; // Mock response
                                ?>
                            </td>
                            <td>
                                <form method="post">
                                    <?php wp_nonce_field('guildnet_update_user_gns', 'guildnet_update_user_gns_nonce'); ?>
                                    <input type="hidden" name="user_id" value="<?php echo esc_attr($user->ID); ?>">
                                    <input type="number" name="new_gns" value="<?php echo esc_attr(get_user_meta($user->ID, 'guildnet_gns', true) ?: 0); ?>" min="0" step="1" style="width: 100px;">
                                    <input type="submit" name="update_user_gns" class="button" value="به‌روزرسانی GNS">
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public static function add_tournament_meta_box() {
        add_meta_box(
            'guildnet_tournament_meta_box',
            'جزئیات تورنمنت',
            [self::class, 'render_tournament_meta_box'],
            'guildnet_tournament',
            'normal',
            'default'
        );
    }

    public static function render_tournament_meta_box($post) {
        $start_date = get_post_meta($post->ID, 'guildnet_start_date', true);
        $end_date = get_post_meta($post->ID, 'guildnet_end_date', true);
        $prize = get_post_meta($post->ID, 'guildnet_prize', true);
        $max_teams = get_post_meta($post->ID, 'guildnet_max_teams', true);
        $status = get_post_meta($post->ID, 'guildnet_status', true);
        $results = get_post_meta($post->ID, 'guildnet_results', true) ?: [];
        wp_nonce_field('guildnet_tournament_meta_box_nonce', 'guildnet_tournament_meta_box_nonce');
        ?>
        <p>
            <label for="guildnet_start_date">تاریخ شروع:</label>
            <input type="date" name="guildnet_start_date" id="guildnet_start_date" value="<?php echo esc_attr($start_date); ?>" required>
        </p>
        <p>
            <label for="guildnet_end_date">تاریخ پایان:</label>
            <input type="date" name="guildnet_end_date" id="guildnet_end_date" value="<?php echo esc_attr($end_date); ?>" required>
        </p>
        <p>
            <label for="guildnet_prize">جایزه (تومان):</label>
            <input type="number" name="guildnet_prize" id="guildnet_prize" value="<?php echo esc_attr($prize); ?>" min="0" step="1">
        </p>
        <p>
            <label for="guildnet_max_teams">حداکثر تعداد تیم‌ها:</label>
            <input type="number" name="guildnet_max_teams" id="guildnet_max_teams" value="<?php echo esc_attr($max_teams); ?>" min="1" step="1">
        </p>
        <p>
            <label for="guildnet_status">وضعیت:</label>
            <select name="guildnet_status" id="guildnet_status">
                <option value="upcoming" <?php selected($status, 'upcoming'); ?>>آتی</option>
                <option value="current" <?php selected($status, 'current'); ?>>جاری</option>
                <option value="past" <?php selected($status, 'past'); ?>>گذشته</option>
            </select>
        </p>
        <h3>نتایج تورنمنت</h3>
        <?php
        $participants = get_post_meta($post->ID, 'guildnet_participants', true) ?: [];
        foreach ($participants as $clan_id => $members) {
            $rank = isset($results[$clan_id]['rank']) ? $results[$clan_id]['rank'] : '';
            ?>
            <p>
                <label>رتبه کلن <?php echo esc_html(get_the_title($clan_id)); ?>:</label>
                <input type="number" name="guildnet_results[<?php echo esc_attr($clan_id); ?>][rank]" value="<?php echo esc_attr($rank); ?>" min="1" step="1">
            </p>
            <?php
        }
    }

    public static function save_tournament_meta_box($post_id) {
        if (!isset($_POST['guildnet_tournament_meta_box_nonce']) || !wp_verify_nonce($_POST['guildnet_tournament_meta_box_nonce'], 'guildnet_tournament_meta_box_nonce')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (isset($_POST['guildnet_start_date'])) {
            update_post_meta($post_id, 'guildnet_start_date', sanitize_text_field($_POST['guildnet_start_date']));
        }

        if (isset($_POST['guildnet_end_date'])) {
            update_post_meta($post_id, 'guildnet_end_date', sanitize_text_field($_POST['guildnet_end_date']));
        }

        if (isset($_POST['guildnet_prize'])) {
            update_post_meta($post_id, 'guildnet_prize', intval($_POST['guildnet_prize']));
        }

        if (isset($_POST['guildnet_max_teams'])) {
            update_post_meta($post_id, 'guildnet_max_teams', intval($_POST['guildnet_max_teams']));
        }

        if (isset($_POST['guildnet_status'])) {
            update_post_meta($post_id, 'guildnet_status', sanitize_text_field($_POST['guildnet_status']));
        }

        if (isset($_POST['guildnet_results']) && is_array($_POST['guildnet_results'])) {
            $results = [];
            foreach ($_POST['guildnet_results'] as $clan_id => $data) {
                $results[$clan_id] = [
                    'rank' => intval($data['rank'])
                ];
            }
            update_post_meta($post_id, 'guildnet_results', $results);
        }

        delete_transient('guildnet_tournaments_list');
    }

    public static function add_clan_meta_box() {
        add_meta_box(
            'guildnet_clan_meta_box',
            'جزئیات کلن',
            [self::class, 'render_clan_meta_box'],
            'guildnet_clan',
            'normal',
            'default'
        );
    }

    public static function render_clan_meta_box($post) {
        $xp = get_post_meta($post->ID, 'guildnet_xp', true) ?: 0;
        $level = get_post_meta($post->ID, 'guildnet_level', true) ?: 1;
        wp_nonce_field('guildnet_clan_meta_box_nonce', 'guildnet_clan_meta_box_nonce');
        ?>
        <p>
            <label for="guildnet_xp">امتیاز کلن (XP):</label>
            <input type="number" name="guildnet_xp" id="guildnet_xp" value="<?php echo esc_attr($xp); ?>" min="0" step="1">
        </p>
        <p>
            <label for="guildnet_level">سطح کلن:</label>
            <input type="number" name="guildnet_level" id="guildnet_level" value="<?php echo esc_attr($level); ?>" min="1" step="1" readonly>
        </p>
        <?php
    }

    public static function save_clan_meta_box($post_id) {
        if (!isset($_POST['guildnet_clan_meta_box_nonce']) || !wp_verify_nonce($_POST['guildnet_clan_meta_box_nonce'], 'guildnet_clan_meta_box_nonce')) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        if (isset($_POST['guildnet_xp'])) {
            $xp = intval($_POST['guildnet_xp']);
            update_post_meta($post_id, 'guildnet_xp', $xp);

            // Update clan level based on XP
            $level = 1;
            if ($xp >= 10000) {
                $level = 5;
            } elseif ($xp >= 6000) {
                $level = 4;
            } elseif ($xp >= 3000) {
                $level = 3;
            } elseif ($xp >= 1000) {
                $level = 2;
            }
            update_post_meta($post_id, 'guildnet_level', $level);
        }
    }
}
?>