<?php
/*
Plugin Name: Guildnet
Description: پلاگین حرفه‌ای گیمینگ برای مدیریت کلن‌ها، تورنمنت‌ها، و امتیازات با UI خفن.
Version: 3.0.0
Author: xAI
License: GPL2
Text Domain: guildnet
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('GUILDNET_VERSION', '3.0.0');
define('GUILDNET_DIR', plugin_dir_path(__FILE__));
define('GUILDNET_URL', plugin_dir_url(__FILE__));

// Include required files
require_once GUILDNET_DIR . 'includes/class-guildnet-core.php';
require_once GUILDNET_DIR . 'includes/class-guildnet-shortcodes.php';
require_once GUILDNET_DIR . 'includes/class-guildnet-ajax.php';
require_once GUILDNET_DIR . 'includes/class-guildnet-woocommerce.php';
require_once GUILDNET_DIR . 'includes/class-guildnet-telegram.php';
require_once GUILDNET_DIR . 'includes/class-guildnet-settings.php';

// Initialize the plugin
add_action('init', function () {
    load_plugin_textdomain('guildnet', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    $guildnet = new Guildnet_Core();
    $guildnet->init();
    Guildnet_Settings::init();
});

// Enqueue styles and scripts
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('guildnet-fontawesome', GUILDNET_URL . 'assets/icons/fontawesome/css/all.min.css', [], GUILDNET_VERSION);
    wp_enqueue_style('guildnet-styles', GUILDNET_URL . 'assets/css/guildnet.css', [], GUILDNET_VERSION);
    wp_enqueue_script('guildnet-scripts', GUILDNET_URL . 'assets/js/guildnet.js', ['jquery'], GUILDNET_VERSION, true);
    wp_localize_script('guildnet-scripts', 'guildnetAjax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('guildnet_nonce')
    ]);
});

// Flush rewrite rules on activation/deactivation
register_activation_hook(__FILE__, function () {
    $guildnet = new Guildnet_Core();
    $guildnet->register_rewrite_rules();
    flush_rewrite_rules();
});

register_deactivation_hook(__FILE__, function () {
    flush_rewrite_rules();
});
?>