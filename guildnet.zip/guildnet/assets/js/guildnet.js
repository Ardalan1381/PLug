jQuery(document).ready(function($) {
    // Helper function to format countdown timer
    function formatCountdown(endDate) {
        const now = new Date().getTime();
        const distance = new Date(endDate).getTime() - now;

        if (distance < 0) {
            return 'پایان یافت';
        }

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        return `${days} روز ${hours}:${minutes}:${seconds}`;
    }

    // Update countdown timers
    function updateCountdowns() {
        $('.countdown-timer').each(function() {
            const endDate = $(this).data('end');
            $(this).text(formatCountdown(endDate));
        });
    }
    setInterval(updateCountdowns, 1000);

    // Load clans
    $('#guildnet-load-clans').click(function() {
        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_load_clans',
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#guildnet-clans-list').html(response.data).hide().fadeIn(500);
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Load tournaments
    $('#guildnet-load-tournaments').click(function() {
        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_load_tournaments',
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#guildnet-tournaments-current').html(response.data.current).hide().fadeIn(500);
                    $('#guildnet-tournaments-upcoming').html(response.data.upcoming).hide().fadeIn(500);
                    $('#guildnet-tournaments-past tbody').html(response.data.past).hide().fadeIn(500);
                    updateCountdowns();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Pay tournament entry fee
    $(document).on('click', '.pay-tournament-entry', function() {
        const tournamentId = $(this).data('tournament-id');
        const clanId = $(this).data('clan-id');
        const entryFee = $(this).data('entry-fee');
        if (!confirm(`آیا مطمئن هستید که می‌خواهید ${entryFee} GNS برای ثبت‌نام در این تورنمنت پرداخت کنید؟`)) return;

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_pay_tournament_entry',
                tournament_id: tournamentId,
                clan_id: clanId,
                entry_fee: entryFee,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#guildnet-load-tournaments').click();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Load join requests
    $('#guildnet-load-join-requests').click(function() {
        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_load_join_requests',
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#guildnet-join-requests').html(response.data).hide().fadeIn(500);
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Load members
    $('#guildnet-load-members').click(function() {
        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_load_members',
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#guildnet-members').html(response.data).hide().fadeIn(500);
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Load tournament registration form
    $('#guildnet-load-tournament-registration').click(function() {
        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_load_tournament_registration',
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#guildnet-tournament-registration').html(response.data).hide().fadeIn(500);
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Create clan
    $('#guildnet-create-clan').submit(function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'guildnet_create_clan');
        formData.append('nonce', guildnetAjax.nonce);

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#guildnet-create-clan')[0].reset();
                    $('#guildnet-load-clans').click();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Join clan
    $(document).on('click', '.join-clan', function() {
        const clanId = $(this).data('clan-id');
        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_join_clan',
                clan_id: clanId,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#guildnet-load-clans').click();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Leave clan
    $('#guildnet-leave-clan').click(function() {
        const clanId = $(this).data('clan-id');
        if (!confirm('آیا مطمئن هستید که می‌خواهید کلن را ترک کنید؟')) return;

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_leave_clan',
                clan_id: clanId,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Update clan
    $('#guildnet-update-clan').submit(function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'guildnet_update_clan');
        formData.append('nonce', guildnetAjax.nonce);

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Approve join request
    $(document).on('click', '.approve-join', function() {
        const userId = $(this).data('user-id');
        const clanId = $(this).data('clan-id');

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_approve_join',
                user_id: userId,
                clan_id: clanId,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#guildnet-load-join-requests').click();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Reject join request
    $(document).on('click', '.reject-join', function() {
        const userId = $(this).data('user-id');
        const clanId = $(this).data('clan-id');

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_reject_join',
                user_id: userId,
                clan_id: clanId,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#guildnet-load-join-requests').click();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Assign role
    $(document).on('change', '.role-select', function() {
        const userId = $(this).data('user-id');
        const clanId = $(this).data('clan-id');
        const role = $(this).val();

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_assign_role',
                user_id: userId,
                clan_id: clanId,
                role: role,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#guildnet-load-members').click();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Kick member
    $(document).on('click', '.kick-member', function() {
        const userId = $(this).data('user-id');
        const clanId = $(this).data('clan-id');
        if (!confirm('آیا مطمئن هستید که می‌خواهید این عضو را اخراج کنید؟')) return;

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_kick_member',
                user_id: userId,
                clan_id: clanId,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#guildnet-load-members').click();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Buy slot
    $('#guildnet-buy-slot').click(function() {
        const clanId = $(this).data('clan-id');
        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_buy_slot',
                clan_id: clanId,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Register for tournament
    $(document).on('submit', '#guildnet-register-tournament', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        formData.append('action', 'guildnet_register_tournament');
        formData.append('nonce', guildnetAjax.nonce);

        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    $('#guildnet-load-tournaments').click();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });

    // Purchase reward
    $('.guildnet-purchase-reward').click(function() {
        const productId = $(this).data('product-id');
        $.ajax({
            url: guildnetAjax.ajax_url,
            method: 'POST',
            data: {
                action: 'guildnet_purchase_reward',
                product_id: productId,
                nonce: guildnetAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message || 'خطایی رخ داد.');
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور.');
            }
        });
    });
});